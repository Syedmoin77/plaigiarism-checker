# PlagiarismCheckerDjangoPython
It is a Full Stack Django Project, for Checking Plagiarism, The Concept used is File Structure. It Contains proper Front End
